%function [path] = myScript(startx,starty,destx,desty)
%javaaddpath('C:\Users\thomas.castelli\Documents\MATLAB\Th�se\UCF UAV Project\Google API\Path planning\*');
%javaaddpath('\home\ni707571\UCF_UAV_Nav\Google_API\Path planning\PathPanel.jar');
javaaddpath('C:\Users\nicol\Desktop\UAV\UCF_UAV_Nav\Google_API\Path planning\PathPanel.jar');
%% Input Maps
Go = imread('../Map_DT_maskGo.png'); 
Go = im2bw(Go);
Go = imresize(Go,1/2);

MaybeGo = imread('../Map_DT_maskMaybeGo.png'); 
MaybeGo = im2bw(MaybeGo);
MaybeGo = imresize(MaybeGo,1/2);
SE = strel('square', 11);
MaybeGo = imerode(MaybeGo,SE);

Map = imresize(imread('../MAP_DT_Final.jpg'),1/4);

figure, imshow(Map);
hold on;

%%% Select points on image
%n = 1;

%while n < 115
    %n = n+1;
%[x,y] = ginput(2);
%print(x)
%startx = x(1); % 266
%startx = 266;
%starty = 242;
%destx = 34;
%desty = 195;
%starty = y(1); % 242
%destx = x(2); % 34
%desty = y(2); % 195

%%% Or give their Location
a = 1;
b = 4000;
d = 2000;
fileExtension = '.txt';

for n = 1:4
    % Generate random starting and ending locations
    %startx =  randi([a b],1,1); % 266
    %starty =  randi([a b],1,1); % 242
     
    %destx =  randi([d b],1,1); % 34
    %desty =  randi([d b],1,1); % 195

    [x,y] = ginput(2);
    
    startx = x(1); 
    starty = y(1); % 242
    destx = x(2); % 34
    desty = y(2); % 195
    
    plot(startx, starty, '+b', 'MarkerSize', 7, 'LineWidth', 2);
    plot(destx, desty, '+b', 'MarkerSize', 7, 'LineWidth', 2);

    dest = [destx,desty]; 
    start = [startx,starty];
    disp(start)
    disp(dest)
    % Generate path
    [value,path] = myFunc(Go,MaybeGo,start,dest);
    
    % Save to textFile
    filename = 'outputGroundTruth\';
    fname = sprintf ('%s%i%s', filename, n, fileExtension);
    save(fname,'path','-ascii')
    filename = 'outputStart\';
    fname = sprintf ('%s%i%s', filename, n, fileExtension);
    save(fname,'startx','starty','-ascii')
    filename = 'outputEnd\';
    fname = sprintf ('%s%i%s', filename, n, fileExtension);
    save(fname,'destx','desty','-ascii')
    disp(n)
end
%dist = 0;
%for ii=1:length(path)-1
    %plot([path(ii,1);path(ii+1,1)],[path(ii,2);path(ii+1,2)],'-b', 'linewidth',3);

    % Euclidian distance traveled
    %dist = dist + sqrt( power( path(ii+1,2) - path(ii,2), 2) + power( path(ii+1,1) - path(ii,1), 2) );
%end

%dist;
%dist_straight = sqrt( power( max(startx, destx) - min(startx, destx), 2 ) + power( max(starty, desty) - min(starty, desty), 2 ) );
%delta_dist_pix = abs(dist - dist_straight)
%delta_dist_percent = dist / dist_straight

%startx = x(1); % 266
%starty = y(1); % 242
%destx = x(2); % 34
%desty = y(2); % 195
%plot(startx, starty, '+b', 'MarkerSize', 7, 'LineWidth', 2);
%plot(destx, desty, '+b', 'MarkerSize', 7, 'LineWidth', 2);

%%% Or give their Location
% startx = 554; % 266
% starty = 494; % 242
% 
% destx = 34; % 34
% desty = 195; % 195

% Acquire and show the path
%dest = [destx,desty]; 
%start = [startx,starty];
%[value,path] = myFunc(Go,MaybeGo,start,dest);

%dist = 0;
%for ii=1:length(path)-1
  %  plot([path(ii,1);path(ii+1,1)],[path(ii,2);path(ii+1,2)],'-b', 'linewidth',3);

    % Euclidian distance traveled
 %   dist = dist + sqrt( power( path(ii+1,2) - path(ii,2), 2) + power( path(ii+1,1) - path(ii,1), 2) );
%end

%dist;
%dist_straight = sqrt( power( max(startx, destx) - min(startx, destx), 2 ) + power( max(starty, desty) - min(starty, desty), 2 ) );
%delta_dist_pix = abs(dist - dist_straight)
%delta_dist_percent = dist / dist_straight
%end