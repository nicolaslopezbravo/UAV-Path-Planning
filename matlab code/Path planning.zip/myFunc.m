function [value,path] = myFunc(Go,MaybeGo,start,dest)

Go = 1 - Go;
MaybeGo = 1 - MaybeGo;
MaybeGo = imfilter(MaybeGo,fspecial('gaussian',[17 17],1));
MaybeGo(MaybeGo~=0) = 1;
%figure, imshow(MaybeGo)

Cost = zeros(size(Go));

Cost(MaybeGo == 1) = 100;
Cost(Go == 0) = 5;
Cost(MaybeGo == 0 & Go == 1) = 20;

[value, ppobj] = shortestpaths(Cost, dest(1), dest(2));
path = getpath(ppobj, start(1), start(2));

end