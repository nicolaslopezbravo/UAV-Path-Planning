
myPath = [];
for numPath = 1:1:8
    
    load([ './Output/path_WPAFB_5-' num2str(numPath) '.mat' ])
    myPath = [ myPath(1:size(myPath,1)-1,:); path ];

end

path = myPath;
save('./Output/path_WPAFB_5.mat', 'path');