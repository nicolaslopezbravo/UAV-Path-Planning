
javaaddpath('C:\Users\thomas.castelli\Documents\MATLAB\Th�se\UCF UAV Project\Google API\Path planning\PathPanel.jar');
%%
close all;
clear all;
clc;

%%% Give GPS location of reference map pixel at (640, 640)
%%% UCF
% latRef = 28.605487; lonRef = -81.207614;
% fileSource = '/UCF/';
% name = 'UCF';

%%% DT
% latRef = 28.553000; lonRef = -81.388908;
% fileSource = '/DT/';
% name = 'DT';

%%% WPAFB
latRef = 39.783277; lonRef = -84.127111;
fileSource = 'WPAFB/';
name = 'WPAFB';

%%% PVLabs
% latRef = 43.878328; lonRef = -78.942999;
% fileSource = 'PVLabs/';
% name = 'PVLabs';

namePath = 'path_WPAFB_test';
% namePath = 'path_PVLabs_9';

scale = 1; % 0.1

load(['../Images-GPS/' fileSource 'Lines/MAPLat.mat']);
load(['../Images-GPS/' fileSource 'Lines/MAPLon.mat']);

%%% Input Maps
Go = imread(['../MAP_' name '_maskGo.png']);
Go = im2bw(Go);
Go = imresize(Go, scale);

MaybeGo = imread(['../MAP_' name '_maskMaybeGo.png']); 
MaybeGo = im2bw(MaybeGo);
MaybeGo = imresize(MaybeGo, scale);
% SE = strel('square', 11);
% MaybeGo = imerode(MaybeGo,SE);

% Map = imresize(imread(['MAP_' name '_Final.jpg']), scale);
Map = imresize(imread(['../MAP_' name '_Final.png']), scale);

figure, imshow(Map);
hold on;

%%% Select points on image
[x,y] = ginput(2);
startx = x(1); % 266
starty = y(1); % 242
destx = x(2); % 34
desty = y(2); % 195
plot(startx, starty, '+b', 'MarkerSize', 7, 'LineWidth', 2);
plot(destx, desty, '+b', 'MarkerSize', 7, 'LineWidth', 2);

%%% Or give their Location
% startx = 2014; % 266
% starty = 2782; % 242
% destx = 2094; % 34
% desty = 3278; % 195

%%% Get and show the path
dest = [destx,desty]; 
start = [startx,starty];
[value, path] = myFunc(Go,MaybeGo,start,dest); % Don't forget there is a gaussian filtering on MaybeGo
save(['.\Output\' namePath '.mat'], 'path');
save(['.\' name '\Paths\' namePath '.mat'], 'path');

dist = 0;
for ii=1:length(path)
    if ii <= length(path)-1
        plot([path(ii,1);
        path(ii+1,1)],[path(ii,2);
        path(ii+1,2)],'-b', 'linewidth',3);
    
        % Euclidian distance traveled
        dist = dist + sqrt( power( path(ii+1,2) - path(ii,2), 2) + power( path(ii+1,1) - path(ii,1), 2) );
    end
    
    % Convert to GPS points
    GPSWaypoints(ii, 1) = MAPLat( path(ii,2) / scale, path(ii,1) / scale );
    GPSWaypoints(ii, 2) = MAPLon( path(ii,2) / scale, path(ii,1) / scale );
    
end

%%% Compute extra distance traveled for safety
% dist;
% dist_straight = sqrt( power( max(startx, destx) - min(startx, destx), 2 ) + power( max(starty, desty) - min(starty, desty), 2 ) );
% delta_dist_pix = abs(dist - dist_straight)
% delta_dist_percent = dist / dist_straight


%%% Writing the path script for Google Earth
delete [name '_PathScript.kml'];
file = fopen(['.\Output\' namePath '_PathScript.kml'], 'w');
header = [ 
'<?xml version="1.0" encoding="UTF-8"?>\n',...
'<kml xmlns="http://www.opengis.net/kml/2.2">\n',...
'  <Document>\n',...
'    <name>Path</name>\n',...
'    <Style id="yellowLineGreenPoly">\n',...
'      <LineStyle>\n',...
'        <color>7f00ffff</color>\n',...
'        <width>4</width>\n',...
'      </LineStyle>\n',...
'      <PolyStyle>\n',...
'        <color>7f00ff00</color>\n',...
'      </PolyStyle>\n',...
'    </Style>\n',...
'    <Placemark>\n',...
'      <name>Absolute Extruded</name>\n',...
'      <styleUrl>#yellowLineGreenPoly</styleUrl>\n',...
'      <LineString>\n',...
'        <extrude>1</extrude>\n',...
'        <tessellate>1</tessellate>\n',...
'        <altitudeMode>relativeToGround</altitudeMode>\n',...
'        <coordinates>\n' ];
fprintf(file, header);

altitude = 100;
for i = 1:size(GPSWaypoints,1)
    data = [ '          %f,%f,%d\n' ];
    fprintf(file, data, GPSWaypoints(i, 2), GPSWaypoints(i, 1), altitude);
end
footer = [ 
'        </coordinates>\n',...
'      </LineString>\n',...
'    </Placemark>\n',...
'  </Document>\n',...
'</kml>' ];
fprintf(file, footer);


%%% Writing the waypoints script for Google Earth
delete [name '_WaypointsScript.kml'];
file = fopen(['.\Output\' namePath '_WaypointsScript.kml'], 'w');
header = [ 
'<?xml version="1.0" encoding="utf-16"?>\n',...
'<Document xmlns="http://www.opengis.net/kml/2.2">\n' ];
fprintf(file, header);

altitudeHome = 22;
altitude = 100;
for i = 1:size(GPSWaypoints,1)
    
    if i == 1 || i == size(GPSWaypoints,1)
        data = [
        '      <Placemark>\n',...
        '        <name>WP H Alt: %d</name>\n',...
        '        <Point>\n',...
        '          <altitudeMode>relativeToGround</altitudeMode>\n',...
        '          <coordinates>%f,%f,%d\n',...
        '    </coordinates>\n',...
        '        </Point>\n',...
        '      </Placemark>\n' ];
        fprintf(file, data, altitudeHome, GPSWaypoints(1, 2), GPSWaypoints(1, 1), altitudeHome);
    else
        data = [
        '      <Placemark>\n',...
        '        <name>WP %d Alt: %d</name>\n',...
        '        <Point>\n',...
        '          <altitudeMode>relativeToGround</altitudeMode>\n',...
        '          <coordinates>%f,%f,%d\n',...
        '    </coordinates>\n',...
        '        </Point>\n',...
        '      </Placemark>\n' ];
        fprintf(file, data, i, altitude, GPSWaypoints(i, 2), GPSWaypoints(i, 1), altitude);
    end

end
footer = [ 
'  </Document>\n'];
fprintf(file, footer);



%%% Writing the waypoints script for Mission planner
delete [name '_WaypointsScript.txt'];
file = fopen(['.\Output\' namePath '_WaypointsScript.txt'], 'w');
header = [ 
'QGC WPL 110\n' ];
fprintf(file, header);

altitudeHome = 22;
altitude = 100;
for i = 1:size(GPSWaypoints,1)
    
    if i == 1
        data = [ '%d %d %d %d %f %f %f %f %f %f %f %d\n' ]; % Set home location
        fprintf(file, data, 0, 1, 0, 16, 0, 0, 0, 0, GPSWaypoints(1, 1), GPSWaypoints(1, 2), altitudeHome, 1);
        
        data = [ '%d %d %d %d %f %f %f %f %f %f %f %d\n' ]; % First waypoint
        fprintf(file, data, i, 0, 3, 16, 0, 0, 0, 0, GPSWaypoints(i, 1), GPSWaypoints(i, 2), altitude, 1);
    else
        if i == size(GPSWaypoints,1)
            data = [ '%d %d %d %d %f %f %f %f %f %f %f %d\n' ]; % Last waypoint
            fprintf(file, data, i, 0, 3, 16, 0, 0, 0, 0, GPSWaypoints(i, 1), GPSWaypoints(i, 2), altitude, 1);
            
            data = [ '%d %d %d %d %f %f %f %f %f %f %f %d\n' ]; % Return to Home
            fprintf(file, data, i+1, 0, 3, 20, 0, 0, 0, 0, 0, 0, 0, 1);
        else
            data = [ '%d %d %d %d %f %f %f %f %f %f %f %d\n' ]; % Waypoints
            fprintf(file, data, i, 0, 3, 16, 0, 0, 0, 0, GPSWaypoints(i, 1), GPSWaypoints(i, 2), altitude, 1);
        end
    end

end

fclose('all');

