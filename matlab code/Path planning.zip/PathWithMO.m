close all
clear all
clc

img = imread('exempleSat.PNG');
figure, imshow(img);
hold on

lineLenghtRatio = 5;
lineWidth = 2;

collisionDetect = 0;
maxVel = 15;
minVel = 1;

%%% Vectors : position X, Y, heading, velocity, point on the line X, Y, collision detection if 0, collision X, Y
%%% Origin for heading at 90� clockwise from up

% Initiallyze objects
vUAV = struct('X', 450,'Y', 600, 'Dir', 190,'Vel', 5, 'X2', [], 'Y2', [], 'Collision', 0, 'CollX', [], 'CollY', [], 'tColli', 0);
vObj(1) = struct('X', 363, 'Y', 404, 'Dir', 90, 'Vel', 10, 'X2', [], 'Y2', [], 'Collision', [], 'CollX', [], 'CollY', [], 'tColli', 0);
vObj(2) = struct('X', 347, 'Y', 340, 'Dir', 90, 'Vel', 10, 'X2', [], 'Y2', [], 'Collision', [], 'CollX', [], 'CollY', [], 'tColli', 0);
vObj(3) = struct('X', 355, 'Y', 335, 'Dir', 90, 'Vel', 10, 'X2', [], 'Y2', [], 'Collision', [], 'CollX', [], 'CollY', [], 'tColli', 0);
vObj(4) = struct('X', 354, 'Y', 489, 'Dir', 90, 'Vel', 10, 'X2', [], 'Y2', [], 'Collision', [], 'CollX', [], 'CollY', [], 'tColli', 0);
vObj(5) = struct('X', 343, 'Y', 527, 'Dir', 90, 'Vel', 10, 'X2', [], 'Y2', [], 'Collision', [], 'CollX', [], 'CollY', [], 'tColli', 0);
vObj(6) = struct('X', 361, 'Y', 547, 'Dir', 90, 'Vel', 10, 'X2', [], 'Y2', [], 'Collision', [], 'CollX', [], 'CollY', [], 'tColli', 0);
vObj(7) = struct('X', 352, 'Y', 572, 'Dir', 90, 'Vel', 10, 'X2', [], 'Y2', [], 'Collision', [], 'CollX', [], 'CollY', [], 'tColli', 0);

plot(vUAV.X, vUAV.Y, 'go');
dx = cos(deg2rad(vUAV.Dir)) * vUAV.Vel * lineLenghtRatio;
dy = sin(deg2rad(vUAV.Dir)) * vUAV.Vel * lineLenghtRatio;
quiver(vUAV.X, vUAV.Y, dx, dy, 'g', 'LineWidth', lineWidth);
vUAV.X2 = dx + vUAV.X;
vUAV.Y2 = dy + vUAV.Y;
text(vUAV.X, vUAV.Y-10, num2str(vUAV.Vel), 'FontName', 'Times New Roman', 'FontSize', 8, 'FontWeight', 'bold', 'color', 'y');


for i=1:size(vObj,2)
    
    % delta on direction
    dx = cos( deg2rad(vObj(i).Dir) ) * vObj(i).Vel * lineLenghtRatio;
    dy = sin( deg2rad(vObj(i).Dir) ) * vObj(i).Vel * lineLenghtRatio;

    % point 2 on direction
    vObj(i).X2 = dx + vObj(i).X;
    vObj(i).Y2 = dy + vObj(i).Y;
    
    % collision detection
    vObj(i).Collision = (vUAV.X - vUAV.X2)*(vObj(i).Y - vObj(i).Y2) - (vUAV.Y - vUAV.Y2)*(vObj(i).X - vObj(i).X2);
    
    if vObj(i).Collision ~= 0
        vObj(i).CollX = ( (vUAV.X * vUAV.Y2 - vUAV.Y * vUAV.X2) * (vObj(i).X - vObj(i).X2) - (vUAV.X - vUAV.X2) * (vObj(i).X * vObj(i).Y2 - vObj(i).Y * vObj(i).X2) ) /  vObj(i).Collision;
        vObj(i).CollY = ( (vUAV.X * vUAV.Y2 - vUAV.Y * vUAV.X2) * (vObj(i).Y - vObj(i).Y2) - (vUAV.Y - vUAV.Y2) * (vObj(i).X * vObj(i).Y2 - vObj(i).Y * vObj(i).X2) ) /  vObj(i).Collision;
                
        tUAV = sqrt( (vUAV.X - vObj(i).CollX)^2 + (vUAV.Y - vObj(i).CollY)^2 ) / vUAV.Vel; % t = dist / vel
        vObj(i).tColli = sqrt( (vObj(i).X - vObj(i).CollX)^2 + (vObj(i).Y - vObj(i).CollY)^2 ) / vObj(i).Vel;
        
        if abs( tUAV - vObj(i).tColli ) < 2 % if there is less than 2 seconds difference the object if a threat
            plot(vObj(i).X, vObj(i).Y, 'ro');
            quiver(vObj(i).X, vObj(i).Y, dx, dy, 'r', 'LineWidth', lineWidth);
            plot(vObj(i).CollX, vObj(i).CollY, 'r*');
            collisionDetect = 1;
        else % good margin
            plot(vObj(i).X, vObj(i).Y, 'co');
            quiver(vObj(i).X, vObj(i).Y, dx, dy, 'c', 'LineWidth', lineWidth);
            plot(vObj(i).CollX, vObj(i).CollY, 'g*');
        end
    else % case where the paths are parallels
        plot(vObj(i).X, vObj(i).Y, 'co');
        quiver(vObj(i).X, vObj(i).Y, dx, dy, 'c', 'LineWidth', lineWidth);
        plot(vObj(i).CollX, vObj(i).CollY, 'g*');
    end
    
    text(vObj(i).X, vObj(i).Y-10, [num2str(i) ', ' num2str(round(vObj(i).tColli, 1)) ', ' num2str(round(tUAV, 1))], 'FontName', 'Times New Roman', 'FontSize', 8, 'FontWeight', 'bold', 'color', 'y');
end
hold off

if collisionDetect == 1 % if collision, find the velocity to avoid all MO
    line = 1;
    v = vUAV.Vel;
    dv = 0.5;
    found = 0;
    while found == 0
        v1 = v + dv;
        colMat(line, 1) = v1;
        for i=1: size(vObj,2)         
            tUAV = sqrt( (vUAV.X - vObj(i).CollX)^2 + (vUAV.Y - vObj(i).CollY)^2 ) / v1; % t = dist / vel
            vObj(i).tColli = sqrt( (vObj(i).X - vObj(i).CollX)^2 + (vObj(i).Y - vObj(i).CollY)^2 ) / vObj(i).Vel;
            
            if abs( tUAV - vObj(i).tColli ) < 2
                colMat(line, i+1) = 1;
            else
                colMat(line, i+1) = 0;
            end
            
        end
        if max(colMat(line,2:end)) == 0
            v1
            vUAV.Vel = v1;
            found = 1;
        end
        
        line = line+1;
        v2 = v - dv;
        colMat(line, 1) = v2;
        for i=1: size(vObj,2)         
            tUAV = sqrt( (vUAV.X - vObj(i).CollX)^2 + (vUAV.Y - vObj(i).CollY)^2 ) / v2; % t = dist / vel
            vObj(i).tColli = sqrt( (vObj(i).X - vObj(i).CollX)^2 + (vObj(i).Y - vObj(i).CollY)^2 ) / vObj(i).Vel;
            
            if abs( tUAV - vObj(i).tColli ) < 2
                colMat(line, i+1) = 1;
            else
                colMat(line, i+1) = 0;
            end
            
        end
        if max(colMat(line,2:end)) == 0
            v2
            vUAV.Vel = v2;
            found = 1;
        end
        line = line+1;
        dv = dv + 0.5;
    end    
    
    % display good solution
    img = imread('exempleSat.PNG');
    figure, imshow(img);
    hold on
    plot(vUAV.X, vUAV.Y, 'go');
    dx = cos(deg2rad(vUAV.Dir)) * vUAV.Vel * lineLenghtRatio;
    dy = sin(deg2rad(vUAV.Dir)) * vUAV.Vel * lineLenghtRatio;
    quiver(vUAV.X, vUAV.Y, dx, dy, 'g', 'LineWidth', lineWidth);
    text(vUAV.X, vUAV.Y-10, num2str(vUAV.Vel), 'FontName', 'Times New Roman', 'FontSize', 8, 'FontWeight', 'bold', 'color', 'y');
    
    for i=1:size(vObj,2)
        % delta on direction
        dx = cos( deg2rad(vObj(i).Dir) ) * vObj(i).Vel * lineLenghtRatio;
        dy = sin( deg2rad(vObj(i).Dir) ) * vObj(i).Vel * lineLenghtRatio;
        % collision detection
        vObj(i).Collision = (vUAV.X - vUAV.X2)*(vObj(i).Y - vObj(i).Y2) - (vUAV.Y - vUAV.Y2)*(vObj(i).X - vObj(i).X2);

        if vObj(i).Collision ~= 0

            tUAV = sqrt( (vUAV.X - vObj(i).CollX)^2 + (vUAV.Y - vObj(i).CollY)^2 ) / vUAV.Vel; % t = dist / vel
            if abs( tUAV - vObj(i).tColli ) < 2 % if there is less than 2 seconds difference the object if a threat
                plot(vObj(i).X, vObj(i).Y, 'ro');
                quiver(vObj(i).X, vObj(i).Y, dx, dy, 'r', 'LineWidth', lineWidth);
                plot(vObj(i).CollX, vObj(i).CollY, 'r*');
                collisionDetect = 1;
            else % good margin
                plot(vObj(i).X, vObj(i).Y, 'co');
                quiver(vObj(i).X, vObj(i).Y, dx, dy, 'c', 'LineWidth', lineWidth);
                plot(vObj(i).CollX, vObj(i).CollY, 'g*');
            end
        else % case where the paths are parallels
            plot(vObj(i).X, vObj(i).Y, 'co');
            quiver(vObj(i).X, vObj(i).Y, dx, dy, 'c', 'LineWidth', lineWidth);
            plot(vObj(i).CollX, vObj(i).CollY, 'g*');
        end

        text(vObj(i).X, vObj(i).Y-10, [num2str(i) ', ' num2str(round(vObj(i).tColli, 1)) ', ' num2str(round(tUAV, 1))], 'FontName', 'Times New Roman', 'FontSize', 8, 'FontWeight', 'bold', 'color', 'y');
    end
    hold off
    
end



